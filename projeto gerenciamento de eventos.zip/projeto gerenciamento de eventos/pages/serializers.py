from rest_framework import serializers
from .models import Evento, Inscricao
from django.contrib.auth.models import User

class EventoSerializer(serializers.ModelSerializer):
    organizador_nome = serializers.CharField(source='organizador.username', read_only=True)
    professor_responsavel_nome = serializers.CharField(source='professor_responsavel.username', read_only=True)
    vagas_restantes = serializers.IntegerField(read_only=True)

    class Meta:
        model = Evento
        fields = (
            'id', 'titulo', 'data_inicio', 'data_fim', 'horario', 
            'local', 'quantidade_participantes', 'vagas_restantes', 
            'organizador_nome', 'professor_responsavel_nome'
        )

class InscricaoSerializer(serializers.ModelSerializer):
    usuario = serializers.HiddenField(default=serializers.CurrentUserDefault()) # Pega o usuário autenticado
    evento_id = serializers.IntegerField(write_only=True) # Campo para receber o ID do evento

    class Meta:
        model = Inscricao
        fields = ('id', 'evento_id', 'data_inscricao', 'usuario')
        read_only_fields = ('data_inscricao', 'usuario')

    def validate(self, data):
        evento_id = data.get('evento_id')
        user = self.context['request'].user
        
        # 1. Valida se o evento existe
        try:
            evento = Evento.objects.get(id=evento_id)
        except Evento.DoesNotExist:
            raise serializers.ValidationError({"evento_id": "Evento não encontrado."})
            
        # 2. Verifica se o usuário já está inscrito
        if Inscricao.objects.filter(usuario=user, evento=evento).exists():
            raise serializers.ValidationError({"non_field_errors": "Você já está inscrito neste evento."})

        # 3. Verifica se o evento está lotado
        if evento.quantidade_participantes > 0:
            if evento.vagas_restantes <= 0:
                raise serializers.ValidationError({"non_field_errors": "Vagas esgotadas!"})
                
        # 4. Verifica se é organizador (Requisito 9)
        if user.perfil.perfil == 'ORGANIZADOR':
            raise serializers.ValidationError({"non_field_errors": "Organizadores não podem se inscrever em eventos."})
            
        # Adiciona o objeto Evento para ser usado no .create()
        data['evento'] = evento
        return data

    def create(self, validated_data):
        # Remove o ID que é write-only e usa o objeto completo
        validated_data.pop('evento_id')
        validated_data['usuario'] = validated_data.pop('usuario')
        return Inscricao.objects.create(**validated_data)