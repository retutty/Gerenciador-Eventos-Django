from django import template
from pages.models import Inscricao

register = template.Library()
@register.filter
def is_inscrito(user, evento):
    """Verifica se o usuário está inscrito no evento."""
    if not user.is_authenticated:
        return False
        
    return Inscricao.objects.filter(participante=user, evento=evento).exists()