from django.db import models
from django.conf import settings
from django.contrib.auth import get_user_model
from datetime import date
import uuid 
from django.db.models.signals import post_save
from django.dispatch import receiver

# Define o objeto User para ser usado em signals e funções auxiliares
User = get_user_model() 

# --- Funções de Ajuda ---

def user_directory_path(instance, filename):
    # O arquivo será carregado em MEDIA_ROOT/eventos/banners/user_<id>/<filename>
    return f'eventos/banners/user_{instance.organizador.id}/{filename}'

# --- Modelos ---

class Perfil(models.Model):
    PERFIS = [
        ('ORGANIZADOR', 'Organizador'),
        ('PROFESSOR', 'Professor'),
        ('ALUNO', 'Aluno'),
    ]
    
    # CORREÇÃO CRÍTICA: Usa settings.AUTH_USER_MODEL para referência segura
    usuario = models.OneToOneField(
        settings.AUTH_USER_MODEL, 
        on_delete=models.CASCADE,
        related_name='perfil'
    )
    nome = models.CharField(max_length=150)
    telefone = models.CharField(max_length=15)
    perfil = models.CharField(
        max_length=15, 
        choices=PERFIS, 
        default='ALUNO'
    )
    email_confirmado = models.BooleanField(default=False)
    codigo_confirmacao = models.CharField(max_length=6, null=True, blank=True)
    
    def __str__(self):
        return f"{self.nome} ({self.get_perfil_display()})"
    
    class Meta:
        verbose_name = "Perfil de Usuário"
        verbose_name_plural = "Perfis de Usuários"

# --- Signals para Gerenciamento de Perfil ---

@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    """Cria um Perfil sempre que um novo User for criado."""
    if created:
        Perfil.objects.create(usuario=instance)

@receiver(post_save, sender=User)
def save_user_profile(sender, instance, **kwargs):
    """Garante que o Perfil seja salvo junto com o User."""
    try:
        instance.perfil.save()
    except Perfil.DoesNotExist:
        # Se o perfil ainda não existir (caso de usuários criados via linha de comando)
        Perfil.objects.create(usuario=instance)

class Evento(models.Model):
    titulo = models.CharField(max_length=200)
    descricao = models.TextField()
    data_inicio = models.DateField()
    data_fim = models.DateField()
    horario = models.TimeField()
    local = models.CharField(max_length=200)
    quantidade_participantes = models.IntegerField(default=0)
    
    organizador = models.ForeignKey(
        settings.AUTH_USER_MODEL, 
        on_delete=models.CASCADE, 
        related_name='eventos_organizados'
    )
    professor_responsavel = models.ForeignKey(
        settings.AUTH_USER_MODEL, 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True,
        related_name='eventos_como_professor'
    )
    banner = models.ImageField(
        upload_to=user_directory_path, 
        null=True, 
        blank=True,
        help_text="Banner do evento (máximo 5MB)."
    )
    
    def esta_ativo(self):
        return self.data_fim >= date.today()

    def __str__(self):
        return self.titulo
    
    class Meta:
        ordering = ['data_inicio']
        
class Inscricao(models.Model):
    evento = models.ForeignKey(Evento, on_delete=models.CASCADE, related_name='inscricoes')
    usuario = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='inscricoes')
    data_inscricao = models.DateTimeField(auto_now_add=True)
    presenca_confirmada = models.BooleanField(default=False)
    
    class Meta:
        unique_together = ('evento', 'usuario')
        verbose_name = "Inscrição"
        verbose_name_plural = "Inscrições"
        
    def __str__(self):
        return f"{self.usuario.username} em {self.evento.titulo}"
        
class Certificado(models.Model):
    inscricao = models.OneToOneField(Inscricao, on_delete=models.CASCADE, related_name='certificado')
    codigo_validacao = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    criado_em = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"Certificado para {self.inscricao.usuario.username} no {self.inscricao.evento.titulo}"

class RegistroAuditoria(models.Model):
    usuario = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True)
    acao = models.CharField(max_length=50)
    detalhes = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"[{self.timestamp.strftime('%Y-%m-%d %H:%M')}] {self.acao} por {self.usuario.username if self.usuario else 'Sistema'}"
    
    class Meta:
        ordering = ['-timestamp']
        verbose_name = "Registro de Auditoria"
        verbose_name_plural = "Registros de Auditoria"

imagem = models.ImageField(
    upload_to='eventos/',   # ← assim fica só em media/eventos/
    blank=True,
    null=True,
    help_text="Imagem do evento (opcional)"
)