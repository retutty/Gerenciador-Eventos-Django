from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import get_user_model
from .models import Evento, Perfil, Inscricao
from django.db import transaction
User = get_user_model()

# --- Formulários de Autenticação e Perfil ---

class UserRegistrationForm(UserCreationForm):
    """
    Formulário de criação de usuário customizado.
    Requisito 7: Garante que o usuário forneça o e-mail no registro.
    """
    email = forms.EmailField(
        required=True,
        label="E-mail",
        widget=forms.EmailInput(attrs={'class': 'form-control'})
    )

    class Meta(UserCreationForm.Meta):
        model = User
        fields = UserCreationForm.Meta.fields + ('email',)

    @transaction.atomic 
    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data["email"]
        
        if commit:
            user.save()
        return user


class PerfilForm(forms.ModelForm):
    """
    Formulário para informações adicionais do Perfil.
    """
    
    # Customiza os campos para usar widgets e classes Bootstrap
    perfil = forms.ChoiceField(
        choices=Perfil.PERFIS,
        label="Tipo de Perfil",
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    
    nome = forms.CharField(
        max_length=150,
        label="Nome Completo",
        widget=forms.TextInput(attrs={'class': 'form-control'})
    )

    telefone = forms.CharField(
        max_length=15,
        label="Telefone",
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': '(XX) 9XXXX-XXXX'})
    )

    class Meta:
        model = Perfil
        fields = ['nome', 'telefone', 'perfil']
        # Note: usuario, email_confirmado, e codigo_confirmacao são gerenciados via views/signals


# --- Formulários de Eventos e Gerenciamento ---

class EventoForm(forms.ModelForm):
    """
    Formulário para criação e edição de Eventos (Requisito 3).
    """
    data_inicio = forms.DateField(
        widget=forms.DateInput(attrs={'type': 'date', 'class': 'form-control'})
    )
    data_fim = forms.DateField(
        widget=forms.DateInput(attrs={'type': 'date', 'class': 'form-control'})
    )
    horario = forms.TimeField(
        widget=forms.TimeInput(attrs={'type': 'time', 'class': 'form-control'})
    )
    
    class Meta:
        model = Evento
        # Campos que o organizador preenche
        fields = [
            'titulo', 'descricao', 'data_inicio', 'data_fim', 'horario', 
            'local', 'quantidade_participantes', 'professor_responsavel', 'banner'
        ]
        widgets = {
            'titulo': forms.TextInput(attrs={'class': 'form-control'}),
            'descricao': forms.Textarea(attrs={'class': 'form-control', 'rows': 4}),
            'local': forms.TextInput(attrs={'class': 'form-control'}),
            'quantidade_participantes': forms.NumberInput(attrs={'class': 'form-control'}),
            'professor_responsavel': forms.Select(attrs={'class': 'form-control'}),
        }
        labels = {
            'professor_responsavel': 'Professor Responsável (Opcional)',
            'quantidade_participantes': 'Capacidade Máxima de Participantes',
        }

