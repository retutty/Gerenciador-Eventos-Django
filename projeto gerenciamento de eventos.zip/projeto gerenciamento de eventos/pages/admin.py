from django.contrib import admin
from .models import Perfil, Evento, Inscricao, Certificado, RegistroAuditoria

# Certifique-se de que só modelos existentes estão sendo importados
# (Excluí 'Mensagem', pois gerou erro em um traceback anterior)

@admin.register(Perfil)
class PerfilAdmin(admin.ModelAdmin):
    list_display = ('usuario', 'nome', 'perfil', 'email_confirmado')
    list_filter = ('perfil', 'email_confirmado')
    search_fields = ('usuario__username', 'nome')

@admin.register(Evento)
class EventoAdmin(admin.ModelAdmin):
    list_display = ('titulo', 'organizador', 'data_inicio', 'local', 'esta_ativo')
    list_filter = ('organizador', 'data_inicio')
    search_fields = ('titulo', 'local')

@admin.register(Inscricao)
class InscricaoAdmin(admin.ModelAdmin):
    list_display = ('evento', 'usuario', 'data_inscricao', 'presenca_confirmada')
    list_filter = ('evento', 'presenca_confirmada')

@admin.register(Certificado)
class CertificadoAdmin(admin.ModelAdmin):
    list_display = ('inscricao', 'codigo_validacao', 'criado_em')

@admin.register(RegistroAuditoria)
class RegistroAuditoriaAdmin(admin.ModelAdmin):
    list_display = ('timestamp', 'usuario', 'acao', 'detalhes')
    readonly_fields = ('timestamp', 'usuario', 'acao', 'detalhes')
    list_filter = ('acao', 'usuario')