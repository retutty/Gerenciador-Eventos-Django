# pages/urls.py

from django.urls import path
from . import views
from django.contrib.auth import views as auth_views 
# --- ADICIONADO: Importação explícita para evitar o AttributeError ---
from .views import gerenciar_certificados, emitir_certificado

urlpatterns = [
    path('', views.home_page, name='home'),
    path('registro/', views.registro_usuario, name='registro'),
    
    # URLs de Autenticação
    path('login/', auth_views.LoginView.as_view(template_name='pages/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(next_page='home'), name='logout'),
    
    # URLs de Eventos
    path('eventos/', views.lista_eventos, name='lista_eventos'),
    path('eventos/criar/', views.criar_evento, name='criar_evento'),
    path('eventos/meus-eventos/', views.meus_eventos, name='meus_eventos'),
    
    # URLs de Ação (que usam o ID do Evento)
    path('eventos/<int:evento_id>/', views.detalhe_evento, name='detalhe_evento'),
    path('eventos/<int:evento_id>/editar/', views.editar_evento, name='editar_evento'),
    path('eventos/<int:evento_id>/excluir/', views.excluir_evento, name='excluir_evento'),
    path('eventos/<int:evento_id>/inscrever/', views.inscrever_evento, name='inscrever_evento'),
    
    # URLs de Certificados (AGORA USANDO A IMPORTAÇÃO EXPLÍCITA)
    # Mudamos 'views.gerenciar_certificados' para 'gerenciar_certificados'
    path('eventos/<int:evento_id>/certificados/', gerenciar_certificados, name='gerenciar_certificados'), 
    path('inscricao/<int:inscricao_id>/emitir/', emitir_certificado, name='emitir_certificado'),
]