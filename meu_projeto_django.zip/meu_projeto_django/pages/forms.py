# pages/forms.py

from django import forms
# Importe o Perfil e o Evento do seu models.py
from .models import Perfil, Evento 

# ------------------------------------------------------------------
# 1. Formulário para estender o usuário padrão (PerfilForm)
# ------------------------------------------------------------------
class PerfilForm(forms.ModelForm):
    # Campos de telefone e instituição que podem ser vazios no formulário
    telefone = forms.CharField(max_length=15, required=False)
    instituicao_de_ensino = forms.CharField(max_length=100, required=False)

    class Meta:
        model = Perfil
        fields = ['nome', 'telefone', 'instituicao_de_ensino', 'perfil']

# ------------------------------------------------------------------
# 2. Formulário para criação/edição de Eventos (EventoForm)
# ------------------------------------------------------------------
class EventoForm(forms.ModelForm):
    class Meta:
        model = Evento
        # Excluímos 'organizador' pois ele será preenchido automaticamente pela view
        fields = [
            'titulo', 
            'tipo', 
            'data_inicio', 
            'data_fim', 
            'horario', 
            'local', 
            'quantidade_participantes'
        ]
        # Personalização opcional para o tipo de input no HTML
        widgets = {
            'data_inicio': forms.DateInput(attrs={'type': 'date'}),
            'data_fim': forms.DateInput(attrs={'type': 'date'}),
            'horario': forms.TimeInput(attrs={'type': 'time'}),
        }