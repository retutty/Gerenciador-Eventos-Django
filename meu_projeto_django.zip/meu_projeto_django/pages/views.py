from django.shortcuts import render, redirect, get_object_or_404 
from django.contrib.auth.decorators import login_required, user_passes_test 
from django.http import HttpResponse 
from django.contrib.auth.forms import UserCreationForm 
from django.db import transaction, IntegrityError 
from django.contrib import messages
from django.db.models import Prefetch
# IMPORTAÇÕES ESSENCIAIS PARA AS VIEWS DE CADASTRO/EVENTOS
from .forms import PerfilForm, EventoForm 
from .models import Mensagem, Perfil, Evento, Inscricao


def is_organizador(user):
    if user.is_authenticated:
        try:
            # Pega o perfil ligado ao usuário e checa se é ORGANIZADOR
            return user.perfil.perfil == 'ORGANIZADOR'
        except Perfil.DoesNotExist:
            return False
    return False


def home_page(request): 
    # Esta função é a que o Django está procurando
    return render(request, 'pages/home.html') 


# --- 2. FUNÇÃO DE REGISTRO
@transaction.atomic
def registro_usuario(request):
    # (Mantenha o resto do código de registro que criamos)
    if request.method == 'POST':
        user_form = UserCreationForm(request.POST)
        perfil_form = PerfilForm(request.POST)

        if user_form.is_valid() and perfil_form.is_valid():
            user = user_form.save()
            perfil = perfil_form.save(commit=False)
            perfil.user = user
            perfil.save()
            return redirect('home')

    else:
        user_form = UserCreationForm()
        perfil_form = PerfilForm()

    return render(request, 'pages/registro.html', {
        'user_form': user_form,
        'perfil_form': perfil_form
    })

def lista_eventos(request):
    # Busca todos os eventos ordenados pela data de início
    eventos = Evento.objects.all().order_by('data_inicio')
    
    context = {
        'eventos': eventos
    }
    return render(request, 'pages/lista_eventos.html', context)


# ------------------------------------------------------------------
# NOVO: DETALHES DE UM EVENTO
# ------------------------------------------------------------------
def detalhe_evento(request, evento_id):
    # Tenta pegar um evento pelo ID, ou retorna erro 404 se não existir
    evento = get_object_or_404(Evento, pk=evento_id)
    
    context = {
        'evento': evento
    }
    return render(request, 'pages/detalhe_evento.html', context)
# ------------------------------------------------------------------
# NOVO: EDITAR EVENTO (Apenas o organizador)
# ------------------------------------------------------------------
@login_required
@user_passes_test(is_organizador, login_url='/')
def editar_evento(request, evento_id):
    # 1. Busca o evento (se não existir, 404)
    evento = get_object_or_404(Evento, pk=evento_id)
    
    # 2. **SEGURANÇA**: Verifica se o usuário logado é o organizador
    if evento.organizador != request.user:
        # Se não for o organizador, redireciona para a lista ou detalhe
        return redirect('detalhe_evento', evento_id=evento.id) 

    if request.method == 'POST':
        # 3. Preenche o formulário com os dados do POST e a instância do evento existente
        form = EventoForm(request.POST, instance=evento) 
        if form.is_valid():
            # O organizador é preservado e o evento é atualizado
            form.save()
            # Redireciona para a página de detalhes do evento editado
            return redirect('detalhe_evento', evento_id=evento.id)
    else:
        # 4. Para o método GET, preenche o formulário com os dados atuais do evento
        form = EventoForm(instance=evento)

    return render(request, 'pages/editar_evento.html', {'form': form, 'evento': evento})
    
# ------------------------------------------------------------------
# NOVO: EXCLUIR EVENTO (Apenas o organizador)
# ------------------------------------------------------------------
@login_required
@user_passes_test(is_organizador, login_url='/')
def excluir_evento(request, evento_id):
    # 1. Busca o evento (se não existir, 404)
    evento = get_object_or_404(Evento, pk=evento_id)
    
    # 2. **SEGURANÇA**: Verifica se o usuário logado é o organizador
    if evento.organizador != request.user:
        # Se não for o organizador, redireciona sem excluir
        return redirect('detalhe_evento', evento_id=evento.id) 

    # 3. Confirmação (apenas via POST)
    if request.method == 'POST':
        evento.delete()
        # Redireciona para a lista de eventos após a exclusão
        return redirect('lista_eventos') 

    # 4. Exibe a página de confirmação (GET)
    return render(request, 'pages/excluir_evento.html', {'evento': evento})


# ------------------------------------------------------------------
# NOVO: LISTAR EVENTOS DO ORGANIZADOR LOGADO
# ------------------------------------------------------------------
@login_required # Só usuários logados podem ver
@user_passes_test(is_organizador, login_url='/') # Só organizadores podem ver
def meus_eventos(request):
    # Filtra os eventos onde o campo 'organizador' é o usuário logado
    eventos = Evento.objects.filter(organizador=request.user).order_by('data_inicio')
    
    context = {
        'eventos': eventos
    }
    return render(request, 'pages/meus_eventos.html', context)


# ------------------------------------------------------------------
#  VERIFICAÇÃO: VIEW DE CRIAÇÃO DE EVENTO
# ------------------------------------------------------------------
@login_required 
@user_passes_test(is_organizador, login_url='/') 
def criar_evento(request):
    if request.method == 'POST':
        form = EventoForm(request.POST)
        if form.is_valid():
            evento = form.save(commit=False)
            evento.organizador = request.user 
            evento.save()
            
            # REDIRECIONE PARA MEUS_EVENTOS APÓS A CRIAÇÃO
            return redirect('meus_eventos')
    else:
        form = EventoForm()

    return render(request, 'pages/criar_evento.html', {'form': form}) 
# ------------------------------------------------------------------
# CORRIGIDO: INSCRIÇÃO EM EVENTOS (COMPLETADO)
# ------------------------------------------------------------------
@login_required
def inscrever_evento(request, evento_id):
    print("INSCRICAO CHAMADA COM ID:", evento_id)
    evento = get_object_or_404(Evento, pk=evento_id)
    participante = request.user

    if request.method == 'POST':
        # 1. Checa se há vagas disponíveis
        vagas_ocupadas = Inscricao.objects.filter(evento=evento).count()
        if vagas_ocupadas >= evento.quantidade_participantes:
            messages.error(request, 'Vagas Esgotadas! Não foi possível realizar a inscrição.')
            return redirect('detalhe_evento', evento_id=evento.id) 

        # 2. Tenta criar a inscrição e captura o erro de duplicidade (IntegrityError)
        try:
            Inscricao.objects.create(
                participante=participante,
                evento=evento
            )
            messages.success(request, 'Inscrição realizada com sucesso!')
            return redirect('detalhe_evento', evento_id=evento.id) 
            
        except IntegrityError: 
            # Ocorre se o participante já estiver inscrito
            messages.warning(request, 'Você já está inscrito neste evento.')
            return redirect('detalhe_evento', evento_id=evento.id)
            
    return redirect('detalhe_evento', evento_id=evento.id)


# ------------------------------------------------------------------
# NOVO: VISÃO GERAL DA EMISSÃO DE CERTIFICADOS
# ------------------------------------------------------------------
@login_required # Só logado
@user_passes_test(is_organizador, login_url='/') # Só organizador
def gerenciar_certificados(request, evento_id):
    evento = get_object_or_404(
        Evento.objects.prefetch_related('inscricoes__participante'), # Pré-carrega inscritos e participantes
        pk=evento_id
    )

    # SEGURANÇA: Só o organizador do evento pode ver
    if evento.organizador != request.user:
        messages.error(request, 'Você não tem permissão para gerenciar certificados deste evento.')
        return redirect('detalhe_evento', evento_id=evento.id)

    # Consulta dos usuários que estão inscritos (vinculado ao evento)
    inscricoes_validas = evento.inscricoes.all()

    context = {
        'evento': evento,
        'inscricoes': inscricoes_validas, # Só é possível emitir certificados para usuários inscritos.
    }
    return render(request, 'pages/gerenciar_certificados.html', context)

# ------------------------------------------------------------------
# NOVO: EMITIR CERTIFICADO
# ------------------------------------------------------------------
@login_required 
def emitir_certificado(request, inscricao_id):
    from .models import Inscricao, Evento # Garanta que Inscricao e Evento estão importados

    inscricao = get_object_or_404(Inscricao, pk=inscricao_id)
    evento = inscricao.evento
    participante = inscricao.participante
    
    # 1. SEGURANÇA: Só o organizador do evento pode emitir
    if evento.organizador != request.user:
        messages.error(request, 'Você não tem permissão para emitir certificados para este evento.')
        return redirect('gerenciar_certificados', evento_id=evento.id)

    # 2. SIMULAÇÃO: Se chegou aqui, a emissão (ou download) foi um sucesso.
    messages.success(request, f'Certificado de {participante.username} emitido com sucesso! (Simulação de Download)')
    return redirect('gerenciar_certificados', evento_id=evento.id)