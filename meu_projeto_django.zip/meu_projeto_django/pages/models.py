# pages/models.py

from django.db import models
from django.contrib.auth.models import User # <-- Linha NECESSÁRIA para ligar ao usuário padrão

# Seu modelo anterior
class Mensagem(models.Model):
    texto = models.CharField(max_length=200)
    data_criacao = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.texto

# ------------------------------------------------------------------
# NOVO MODELO: PERFIL (para estender o usuário padrão)
# ------------------------------------------------------------------

class Perfil(models.Model):
    # Opções para o campo Perfil
    PERFIS = (
        ('ALUNO', 'Aluno'),
        ('PROFESSOR', 'Professor'),
        ('ORGANIZADOR', 'Organizador'),
    )

    # Campo que liga este perfil ao usuário nativo do Django (User)
    user = models.OneToOneField(User, on_delete=models.CASCADE)

    # Campos obrigatórios
    nome = models.CharField(max_length=100)
    telefone = models.CharField(max_length=15)
    perfil = models.CharField(max_length=20, choices=PERFIS)

    # Instituição de ensino (Opcional para "ORGANIZADOR")
    instituicao_de_ensino = models.CharField(
        max_length=100, 
        blank=True, # Permite ser vazio no formulário
        null=True # Permite ser vazio no banco de dados
    )

    def __str__(self):
        return f'Perfil de {self.user.username}'
    
    # ------------------------------------------------------------------
# NOVO MODELO: EVENTO
# ------------------------------------------------------------------

class Evento(models.Model):
    # Tipos de Evento
    TIPOS = (
        ('SEMINARIO', 'Seminário'),
        ('PALESTRA', 'Palestra'),
        ('WORKSHOP', 'Workshop'),
        ('OUTRO', 'Outro'),
    )

    # Dados do Evento
    titulo = models.CharField(max_length=255)
    tipo = models.CharField(max_length=20, choices=TIPOS)

    # Datas e Horários
    data_inicio = models.DateField()
    data_fim = models.DateField()
    horario = models.TimeField()

    # Local e Participantes
    local = models.CharField(max_length=255)
    quantidade_participantes = models.IntegerField(default=0)

    # Organizador Responsável (Liga o evento ao usuário que o criou)
    organizador = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return f'Evento: {self.titulo} ({self.tipo})'
    # ------------------------------------------------------------------
# NOVO: MODELO DE INSCRIÇÃO
# ------------------------------------------------------------------
class Inscricao(models.Model):
    # Relacionamento com o usuário que está se inscrevendo
    participante = models.ForeignKey(User, on_delete=models.CASCADE, related_name='inscricoes')
    
    # Relacionamento com o evento
    evento = models.ForeignKey(Evento, on_delete=models.CASCADE, related_name='inscricoes')
    
    # Data e hora da inscrição
    data_inscricao = models.DateTimeField(auto_now_add=True)

    class Meta:
        # Garante que um participante só possa se inscrever UMA VEZ no mesmo evento
        unique_together = ('participante', 'evento')
        verbose_name = "Inscrição"
        verbose_name_plural = "Inscrições"

    def __str__(self):
        return f'{self.participante.username} inscrito em {self.evento.titulo}'