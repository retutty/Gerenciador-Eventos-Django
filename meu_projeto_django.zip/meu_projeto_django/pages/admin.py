# pages/admin.py
from django.contrib import admin
from .models import Mensagem, Perfil, Evento 
admin.site.register(Mensagem)
admin.site.register(Perfil)
admin.site.register(Evento) 